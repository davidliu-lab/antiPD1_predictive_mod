#!/bin/bash
/bin/circos -conf ../input/TotalCN_circos/progressors/conf_classici.txt -outputfile validation_progressors
/bin/circos -conf ../input/TotalCN_circos/responders/conf_classici.txt -outputfile validation_responders
