draw_confusion_matrix <- function(cm) {
  
  layout(matrix(c(1,1,2)))
  par(mar=c(2,2,2,2))
  plot(c(100, 345), c(300, 450), type = "n", xlab="", ylab="", xaxt='n', yaxt='n')
  title('CONFUSION MATRIX', cex.main=2)
  
  # create the matrix 
  rect(150, 430, 240, 370, col='#3F97D0')
  text(195, 435, 'Class1', cex=1.2)
  rect(250, 430, 340, 370, col='#F7AD50')
  text(295, 435, 'Class2', cex=1.2)
  text(125, 370, 'Predicted', cex=1.3, srt=90, font=2)
  text(245, 450, 'Actual', cex=1.3, font=2)
  rect(150, 305, 240, 365, col='#F7AD50')
  rect(250, 305, 340, 365, col='#3F97D0')
  text(140, 400, 'Class1', cex=1.2, srt=90)
  text(140, 335, 'Class2', cex=1.2, srt=90)
  
  # add in the cm results 
  res <- as.numeric(cm$table)
  text(195, 400, res[1], cex=1.6, font=2, col='white')
  text(195, 335, res[2], cex=1.6, font=2, col='white')
  text(295, 400, res[3], cex=1.6, font=2, col='white')
  text(295, 335, res[4], cex=1.6, font=2, col='white')
  
  # add in the specifics 
  plot(c(100, 0), c(100, 0), type = "n", xlab="", ylab="", main = "DETAILS", xaxt='n', yaxt='n')
  text(10, 85, names(cm$byClass[1]), cex=1.2, font=2)
  text(10, 70, round(as.numeric(cm$byClass[1]), 3), cex=1.2)
  text(30, 85, names(cm$byClass[2]), cex=1.2, font=2)
  text(30, 70, round(as.numeric(cm$byClass[2]), 3), cex=1.2)
  text(50, 85, names(cm$byClass[5]), cex=1.2, font=2)
  text(50, 70, round(as.numeric(cm$byClass[5]), 3), cex=1.2)
  text(70, 85, names(cm$byClass[6]), cex=1.2, font=2)
  text(70, 70, round(as.numeric(cm$byClass[4]), 3), cex=1.2)
  text(90, 85, names(cm$byClass[7]), cex=1.2, font=2)
  text(90, 70, round(as.numeric(cm$byClass[7]), 3), cex=1.2)
  
  # add in the accuracy information 
  text(30, 35, names(cm$overall[1]), cex=1.5, font=2)
  text(30, 20, round(as.numeric(cm$overall[1]), 3), cex=1.4)
  text(70, 35, names(cm$overall[2]), cex=1.5, font=2)
  text(70, 20, round(as.numeric(cm$overall[2]), 3), cex=1.4)
}

decisionplot <- function(model, data, class = NULL, predict_type = "class",
                         resolution = 100, showgrid = TRUE, ...) {
  
  if(!is.null(class)) cl <- data[,class] else cl <- 1
  data <- data[,1:2]
  k <- length(unique(cl))
  
  plot(data, xlim=c(0,1), ylim=c(1.5,5.1), col = as.integer(cl)+1L, pch = as.integer(cl)+1L, ...)
  
  # make grid
  r <- sapply(data, range, na.rm = TRUE)
  xs <- seq(r[1,1], r[2,1], length.out = resolution)
  ys <- seq(r[1,2], r[2,2], length.out = resolution)
  g <- cbind(rep(xs, each=resolution), rep(ys, time = resolution))
  colnames(g) <- colnames(r)
  g <- as.data.frame(g)
  
  ### guess how to get class labels from predict
  ### (unfortunately not very consistent between models)
  p <- predict(model, g, type = predict_type)
  if(is.list(p)) p <- p$class
  p <- as.factor(p)
  
  if(showgrid) points(g, col = as.integer(p)+1L, pch = ".")
  
  z <- matrix(as.integer(p), nrow = resolution, byrow = TRUE)
  contour(xs, ys, z, add = TRUE, drawlabels = FALSE,
          lwd = 2, levels = (1:(k-1))+.5)
  
  invisible(z)
}


ggforest3 <- function (model,
                       data = NULL,
                       main = "Hazard ratio",
                       cpositions = c(0.02,0.22, 0.4),
                       fontsize = 0.7,
                       refLabel = "reference",
                       noDigits = 2,
                       font.x.size = 20)
{
  # dependencies
  require(broom)
  require(survival)
  require(grid)
  .get_data <- function(fit, data = NULL, complain = TRUE) {
    if(is.null(data)){
      if (complain)
        warning ("The `data` argument is not provided. Data will be extracted from model fit.")
      data <- eval(fit$call$data)
      if (is.null(data))
        stop("The `data` argument should be provided either to ggsurvfit or survfit.")
    }
    data
  } # end dependencies
  
  conf.high <- conf.low <- estimate <- NULL
  stopifnot(inherits(model, "coxph"))
  data <- .get_data(model, data = data)
  terms <- attr(model$terms, "dataClasses")[-1]
  coef <- as.data.frame(tidy(model, conf.int = TRUE))
  gmodel <- glance(model)
  allTerms <- lapply(seq_along(terms), function(i) {
    var <- names(terms)[i]
    if (terms[i] %in% c("factor", "character")) {
      adf <- as.data.frame(table(data[, var]))
      cbind(var = var, adf, pos = 1:nrow(adf))
    }
    else if (terms[i] == "numeric") {
      data.frame(
        var = var,
        Var1 = "",
        Freq = nrow(data),
        pos = 1
      )
    }
    else {
      vars = grep(paste0("^", var, "*."), coef$term, value = TRUE)
      data.frame(
        var = vars,
        Var1 = "",
        Freq = nrow(data),
        pos = seq_along(vars)
      )
    }
  })
  allTermsDF <- do.call(rbind, allTerms)
  colnames(allTermsDF) <- c("var", "level", "N", "pos")
  inds <- apply(allTermsDF[, 1:2], 1, paste0, collapse = "")
  rownames(coef) <- gsub(coef$term, pattern = "`", replacement = "")
  toShow <- cbind(allTermsDF, coef[inds,])[, c("var",
                                               "level",
                                               "N",
                                               "p.value",
                                               "estimate",
                                               "conf.low",
                                               "conf.high",
                                               "pos")]
  toShowExp <- toShow[, 5:7]
  toShowExp[is.na(toShowExp)] <- 0
  toShowExp <- format(exp(toShowExp), digits = noDigits)
  toShowExpClean <- data.frame(toShow, pvalue = signif(toShow[,
                                                              4], noDigits + 1), toShowExp)
  toShowExpClean$stars <- paste0(
    round(toShowExpClean$p.value,
          noDigits + 1),
    " ",
    ifelse(toShowExpClean$p.value <
             0.05, "*", ""),
    ifelse(toShowExpClean$p.value < 0.01,
           "*", ""),
    ifelse(toShowExpClean$p.value < 0.001, "*",
           "")
  )
  toShowExpClean$ci <- paste0("(", toShowExpClean[, "conf.low.1"],
                              " - ", toShowExpClean[, "conf.high.1"], ")")
  toShowExpClean$estimate.1[is.na(toShowExpClean$estimate)] = refLabel
  toShowExpClean$stars[which(toShowExpClean$p.value < 0.001)] = "<0.001 ***"
  toShowExpClean$stars[is.na(toShowExpClean$estimate)] = ""
  toShowExpClean$ci[is.na(toShowExpClean$estimate)] = ""
  toShowExpClean$estimate[is.na(toShowExpClean$estimate)] = 0
  toShowExpClean$var = as.character(toShowExpClean$var)
  toShowExpClean$var[duplicated(toShowExpClean$var)] = ""
  toShowExpClean$N <- paste0("(N=", toShowExpClean$N, ")")
  toShowExpClean <- toShowExpClean[nrow(toShowExpClean):1,]
  rangeb <-
    range(toShowExpClean$conf.low, toShowExpClean$conf.high,
          na.rm = TRUE)
  breaks <- axisTicks(rangeb / 2, log = TRUE, nint = 7)
  rangeplot <- rangeb
  rangeplot[1] <- rangeplot[1] - diff(rangeb)
  rangeplot[2] <- rangeplot[2] + 0.15 * diff(rangeb)
  width <- diff(rangeplot)
  y_variable <- rangeplot[1] + cpositions[1] * width
  y_nlevel <- rangeplot[1] + cpositions[2] * width
  y_cistring <- rangeplot[1] + cpositions[3] * width
  y_stars <- rangeb[2]
  x_annotate <- seq_len(nrow(toShowExpClean))
  annot_size_mm <-
    fontsize * as.numeric(convertX(unit(theme_get()$text$size,
                                        "pt"), "mm"))
  p <- ggplot(toShowExpClean, aes(seq_along(var), exp(estimate))) +
    geom_rect(
      aes(
        xmin = seq_along(var) - 0.5,
        xmax = seq_along(var) +
          0.5,
        ymin = exp(rangeplot[1]),
        ymax = exp(rangeplot[2]),
        fill = ordered(seq_along(var) %% 2 + 1)
      )
    ) + scale_fill_manual(values = c("#FFFFFF33",
                                     "#00000033"),
                          guide = "none") + geom_point(pch = 15,
                                                       size = 4) + geom_errorbar(aes(ymin = exp(conf.low),
                                                                                     ymax = exp(conf.high)), width = 0.15) + geom_hline(yintercept = 1,
                                                                                                                                        linetype = 3) + coord_flip(ylim = exp(rangeplot)) +
    ggtitle(main) + scale_y_log10(
      name = "",
      labels = sprintf("%g",
                       breaks),
      expand = c(0.02, 0.02),
      breaks = breaks
    ) +
    theme_light() + theme(
      panel.grid.minor.y = element_blank(),
      panel.grid.minor.x = element_blank(),
      panel.grid.major.y = element_blank(),
      legend.position = "none",
      panel.border = element_blank(),
      axis.title.y = element_blank(),
      axis.text.y = element_blank(),
      # Modified here
      axis.text.x = element_text(size=font.x.size),
      # End modification
      axis.ticks.y = element_blank(),
      plot.title = element_text(hjust = 0.5)
    ) +
    xlab("") + annotate(
      geom = "text",
      x = x_annotate,
      y = exp(y_variable),
      label = toShowExpClean$var,
      fontface = "bold",
      hjust = 0,
      size = annot_size_mm
    ) + annotate(
      geom = "text",
      x = x_annotate,
      y = exp(y_nlevel),
      hjust = 0,
      label = toShowExpClean$level,
      vjust = -0.1,
      size = annot_size_mm
    ) + annotate(
      geom = "text",
      x = x_annotate,
      y = exp(y_nlevel),
      label = toShowExpClean$N,
      fontface = "italic",
      hjust = 0,
      vjust = ifelse(toShowExpClean$level ==
                       "", 0.5, 1.1),
      size = annot_size_mm
    ) + annotate(
      geom = "text",
      x = x_annotate,
      y = exp(y_cistring),
      label = toShowExpClean$estimate.1,
      size = annot_size_mm,
      vjust = ifelse(toShowExpClean$estimate.1 ==
                       "reference", 0.5,-0.1)
    ) + annotate(
      geom = "text",
      x = x_annotate,
      y = exp(y_cistring),
      label = toShowExpClean$ci,
      size = annot_size_mm,
      vjust = 1.1,
      fontface = "italic"
    ) +
    annotate(
      geom = "text",
      x = x_annotate,
      y = exp(y_stars),
      label = toShowExpClean$stars,
      size = annot_size_mm,
      hjust = -0.2,
      fontface = "italic"
    ) + annotate(
      geom = "text",
      x = 0.5,
      y = exp(y_variable),
      label = paste0(
        "# Events: ",
        gmodel$nevent,
        "; Global p-value (Log-Rank): ",
        format.pval(gmodel$p.value.log, eps = ".001"),
        " \nAIC: ",
        round(gmodel$AIC, 2),
        "; Concordance Index: ",
        round(gmodel$concordance,
              2)
      ),
      size = annot_size_mm,
      hjust = 0,
      vjust = 1.2,
      fontface = "italic"
    )
  gt <- ggplot_gtable(ggplot_build(p))
  gt$layout$clip[gt$layout$name == "panel"] <- "off"
  ggpubr::as_ggplot(gt)
}

metric_calculator <- function(data, lev = NULL, model = NULL) {
  conf_mat <- caret::confusionMatrix(data$pred, data$obs)
  pos_pred_value <- conf_mat$byClass["Pos Pred Value"]
  sensitivity <- conf_mat$byClass["Sensitivity"]
  specificity <- conf_mat$byClass["Specificity"]
  #F1_score <- 2 * (pos_pred_value * (sensitivity^0.5)) / (pos_pred_value + (sensitivity^0.5))
  F1_score <- 2 * (pos_pred_value * (sensitivity)) / (pos_pred_value + (sensitivity))
  names(F1_score) <- "F1_score"
  res <- c(Sensitivity = sensitivity, Pos_pred_value = pos_pred_value, Specificity = specificity, F1 = F1_score)
  return(res)
}

### k-fold cross validation
decision_tree_k_fold_CV <- function(x, positiveWeight, negativeWeight) {
  # Create model and gather metrics before cross validation
  modelWeights <- ifelse(x$PD == 1, positiveWeight, negativeWeight)
  model <- rpart(PD ~ het + ploidy, data = x, method = "class", weights = modelWeights, minbucket = 10)
  y_pred_dt <- predict(model, x, type = "class")
  x$DT_pred <- relevel(y_pred_dt, ref = 2)
  x$DT_pred <- factor(y_pred_dt, levels = levels(x$PD))
  conf_mat <- caret::confusionMatrix(x$DT_pred, x$PD)
  original_TP <- conf_mat$table[1, 1]
  original_FP <- conf_mat$table[1, 2]
  original_PPV <- conf_mat$byClass[["Pos Pred Value"]]
  original_sensitivity <- conf_mat$byClass[["Sensitivity"]]
  original_specificity <- conf_mat$byClass[["Specificity"]]
  # Specify how we want to train the model
  ctrl <- trainControl(
    method = "repeatedcv", # Method is repeated cross-validation
    number = 4, # Number of folds
    repeats = 10, # Repeats for repeated k-fold cross-validation
    summaryFunction = metric_calculator, # Specify the custom summary function for PPV
    returnResamp = "all",
    savePredictions = "all"
  )
  # Set parameters for the training
  tune_grid <- expand.grid(cp = c(0.01))
  # Run CV of the model
  validated_tree <- train(PD ~ het + ploidy,
                          data = x,
                          method = "rpart",
                          trControl = ctrl,
                          tuneGrid = tune_grid,
                          weights = modelWeights,
                          control = rpart.control(method = "class", minbucket = 10),
                          metric = "Pos_pred_value.Pos Pred Value"
  )
  # Get cross validated PPV and sensitivity and return results
  cv_PPV <- validated_tree$results[["Pos_pred_value.Pos Pred Value"]]
  cv_PPV_SD <- validated_tree$results[["Pos_pred_value.Pos Pred ValueSD"]]
  cv_PPV_SE <- cv_PPV_SD / sqrt(validated_tree$control$number * validated_tree$control$repeats)
  
  cv_sensitivity <- validated_tree$results[["Sensitivity.Sensitivity"]]
  cv_sensitivity_SD <- validated_tree$results[["Sensitivity.SensitivitySD"]]
  cv_sensitivity_SE <- cv_sensitivity_SD / sqrt(validated_tree$control$number * validated_tree$control$repeats)
  
  cv_specificity <- validated_tree$results[["Specificity.Specificity"]]
  cv_specificity_SD <- validated_tree$results[["Specificity.SpecificitySD"]]
  cv_specificity_SE <- cv_specificity_SD / sqrt(validated_tree$control$number * validated_tree$control$repeats)
  
  cv_F1_score <- validated_tree$results[["F1.F1_score"]]
  cv_F1_score_SD <- validated_tree$results[["F1.F1_scoreSD"]]
  cv_F1_score_SE <- cv_F1_score_SD / sqrt(validated_tree$control$number * validated_tree$control$repeats)
  
  # Adjusted PPV
  PPV_vector <- validated_tree[["resample"]][["Pos_pred_value.Pos Pred Value"]]
  PPV_vector[is.na(PPV_vector)] <- 0
  adj_cv_PPV <- mean(PPV_vector)
  
  results <- list(
    "model" = model,
    "validated_model" = validated_tree,
    "FP" = original_FP,
    "TP" = original_TP,
    "PPV" = original_PPV,
    "Specificity" = original_specificity,
    "Sensitivity" = original_sensitivity,
    "adj_cv_PPV" = adj_cv_PPV,
    "cv_PPV" = cv_PPV,
    "cv_PPV_SD" = cv_PPV_SD,
    "cv_PPV_SE" = cv_PPV_SE,
    "cv_F1_score" = cv_F1_score,
    "cv_F1_score_SD" = cv_F1_score_SD,
    "cv_F1_score_SE" = cv_F1_score_SE,
    "cv_specificity" = cv_specificity,
    "cv_specificity_SD" = cv_specificity_SD,
    "cv_specificity_SE" = cv_specificity_SE,
    "cv_sensitivity" = cv_sensitivity,
    "cv_sensitivity_SD" = cv_sensitivity_SD,
    "cv_sensitivity_SE" = cv_sensitivity_SE
  )
  return(results)
}
